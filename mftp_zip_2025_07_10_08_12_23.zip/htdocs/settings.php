<?php
# ItsYaboyNathan
$name = "Nathan";
$discord = "https://discord.gg/buVWCfXeBF";
$image = "https://i.pinimg.com/originals/e9/3c/76/e93c766198a8db2656d42fc17dca722f.gif";
$color = "00000";
$adminhook = "";
?>